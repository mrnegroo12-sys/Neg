package com.sketchbot.app

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** الثيم الدافئ (كريمي + برتقالي + بني داكن) */
object Th {
    val CREAM = Color.parseColor("#FCF3EA")
    val CARD = Color.parseColor("#FFF8F1")
    val LINE = Color.parseColor("#F0DFCD")
    val BROWN = Color.parseColor("#3A1A0C")
    val MUTED = Color.parseColor("#8C5E42")
    val TAN = Color.parseColor("#B98D6B")
    val O1 = Color.parseColor("#FFA23A")
    val O2 = Color.parseColor("#E5470B")
    val NAV1 = Color.parseColor("#3E1F0F")
    val NAV2 = Color.parseColor("#2A1309")

    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun pressable(v: View) {
        v.isClickable = true
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    fun squareBtn(ctx: Context, icon: Int, ink: Int, sizeDp: Float = 46f, orange: Boolean = false, outlined: Boolean = false): FrameLayout {
        val d = ctx.resources.displayMetrics.density
        val f = FrameLayout(ctx)
        f.background = WarmDrawable(if (orange) WarmDrawable.ORANGE else if (outlined) WarmDrawable.OUTLINE else WarmDrawable.BTN, 16f, d)
        val s = (sizeDp * 0.48f * d).toInt()
        f.addView(IconView(ctx, icon, 0, 0, if (orange) Color.WHITE else ink), FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        pressable(f)
        return f
    }

    fun text(ctx: Context, s: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(ctx).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = android.graphics.Typeface.create("sans-serif-medium", if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }
}

/** خلفيات الثيم الدافئ */
class WarmDrawable(
    private val mode: Int,
    private val rDp: Float,
    private val d: Float,
    private val topOnly: Boolean = false
) : Drawable() {
    companion object {
        const val CARD = 0
        const val ORANGE = 1
        const val BTN = 2
        const val NAV = 3
        const val ACTIVE = 4
        const val SOFT = 5
        const val OUTLINE = 6
        const val PANEL = 7
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(1f, d) }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private var hasLine = true
    private var hasGloss = false

    override fun onBoundsChange(b: Rect) {
        rect.set(b.left + 0.5f * d, b.top + 0.5f * d, b.right - 0.5f * d, b.bottom - 0.5f * d)
        val top = rect.top
        val bot = rect.bottom
        when (mode) {
            CARD -> { fill.shader = null; fill.color = Th.CARD; line.color = Th.LINE }
            BTN -> { fill.shader = null; fill.color = Color.parseColor("#FFFBF6"); line.color = Th.LINE }
            SOFT -> { fill.shader = null; fill.color = Color.parseColor("#F7E7D6"); hasLine = false }
            PANEL -> { fill.shader = null; fill.color = Color.argb(0xF4, 255, 247, 238); line.color = Color.parseColor("#F6D7B0"); line.strokeWidth = 1.5f * d }
            OUTLINE -> { fill.shader = null; fill.color = Color.parseColor("#FFFBF6"); line.color = Th.O1; line.strokeWidth = 1.6f * d }
            ORANGE -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Th.O1, Th.O2, Shader.TileMode.CLAMP)
                line.color = Color.argb(0x70, 255, 205, 150)
                gloss.shader = LinearGradient(0f, top, 0f, top + (bot - top) * 0.55f, Color.argb(0x50, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
                hasGloss = true
            }
            NAV -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Th.NAV1, Th.NAV2, Shader.TileMode.CLAMP)
                hasLine = false
            }
            ACTIVE -> {
                fill.shader = LinearGradient(0f, top, 0f, bot, Color.argb(0xC0, 150, 70, 20), Color.argb(0xA0, 90, 40, 12), Shader.TileMode.CLAMP)
                line.color = Color.argb(0xE0, 255, 138, 31)
                line.strokeWidth = 1.5f * d
            }
        }
        path.reset()
        val r = rDp * d
        if (topOnly) path.addRoundRect(rect, floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f), Path.Direction.CW)
        else path.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    override fun draw(c: Canvas) {
        c.drawPath(path, fill)
        if (hasGloss) c.drawPath(path, gloss)
        if (hasLine) c.drawPath(path, line)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** مفتاح تبديل برتقالي بزرّ أبيض */
class WarmSwitch(ctx: Context) : View(ctx) {
    var checked: Boolean = true
        set(v) { field = v; invalidate() }
    var onChange: ((Boolean) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        setShadowLayer(4f * ctx.resources.displayMetrics.density, 0f, 2f, Color.argb(0x45, 0, 0, 0))
    }
    private val rect = RectF()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        setOnClickListener { checked = !checked; onChange?.invoke(checked) }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(Th.dp(context, 54f), Th.dp(context, 32f))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        rect.set(0f, 0f, w, h)
        track.shader = if (checked) LinearGradient(0f, 0f, w, 0f, Color.parseColor("#F26B1D"), Color.parseColor("#FFA23A"), Shader.TileMode.CLAMP) else null
        if (!checked) track.color = Color.parseColor("#E4D3C2")
        c.drawRoundRect(rect, h / 2f, h / 2f, track)
        val r = h / 2f - 3.5f * resources.displayMetrics.density
        val cx = if (checked) w - h / 2f else h / 2f
        c.drawCircle(cx, h / 2f, r, knob)
    }
}

/** عنصر شريط التنقّل السفلي */
class NavItem(ctx: Context, icon: Int, caption: String) : LinearLayout(ctx) {
    private val ic = IconView(ctx, icon, 0, 0, Th.TAN)
    private val tv = TextView(ctx)
    private val d = ctx.resources.displayMetrics.density

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        val s = (26 * d).toInt()
        addView(ic, LayoutParams(s, s))
        tv.text = caption
        tv.textSize = 13f
        tv.gravity = Gravity.CENTER
        tv.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        addView(tv, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { topMargin = (3 * d).toInt() })
        setActive(false)
        Th.pressable(this)
    }

    fun setActive(a: Boolean) {
        ic.setInk(if (a) Color.WHITE else Th.TAN)
        tv.setTextColor(if (a) Color.WHITE else Th.TAN)
        background = if (a) WarmDrawable(WarmDrawable.ACTIVE, 22f, d) else null
    }
}

fun orangeThumb(ctx: Context): GradientDrawable {
    val d = ctx.resources.displayMetrics.density
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.WHITE)
        setStroke((3 * d).toInt(), Color.parseColor("#F5701D"))
        setSize((26 * d).toInt(), (26 * d).toInt())
    }
}

/** حاوية أفقية: عند اللمس تتساقط منها قطرات ماء */
open class DropLinear(ctx: Context) : LinearLayout(ctx) {
    private class P(val x: Float, val y: Float, val vx: Float, val vy: Float, val r: Float, val born: Long)

    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(0xD0, 255, 255, 255) }
    private val rnd = java.util.Random()
    private val den = ctx.resources.displayMetrics.density
    var dropColor: Int = Color.parseColor("#FF8A1F")

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
        isClickable = true
    }

    private fun spawn(x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        for (i in 0 until 9) {
            ps.add(
                P(
                    x + (rnd.nextFloat() - 0.5f) * 24f * den, y,
                    (rnd.nextFloat() - 0.5f) * 80f * den, rnd.nextFloat() * 50f * den,
                    (2f + rnd.nextFloat() * 2.6f) * den, now
                )
            )
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                spawn(e.x.coerceIn(0f, width.toFloat()), height * 0.75f)
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        return super.onTouchEvent(e)
    }

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        if (ps.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        val it = ps.iterator()
        while (it.hasNext()) {
            val p = it.next()
            val t = (now - p.born) / 1000f
            if (t > 0.85f) { it.remove(); continue }
            val px = p.x + p.vx * t
            val py = p.y + p.vy * t + 0.5f * 1200f * den * t * t
            val a = ((1f - t / 0.85f) * 255).toInt().coerceIn(0, 255)
            paint.color = Color.argb(a, Color.red(dropColor), Color.green(dropColor), Color.blue(dropColor))
            c.drawCircle(px, py, p.r, paint)
            hl.alpha = (a * 0.8f).toInt()
            c.drawCircle(px - p.r * 0.3f, py - p.r * 0.3f, p.r * 0.32f, hl)
        }
        if (ps.isNotEmpty()) postInvalidateOnAnimation()
    }
}

/** زر اللوحة العائمة: بلاطة زجاجية بقطرات ماء + نص */
class WaterButton(ctx: Context, icon: Int, caption: String, c1: Int, c2: Int, glyph: Int = 0) : DropLinear(ctx) {
    init {
        val d = ctx.resources.displayMetrics.density
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = WarmDrawable(WarmDrawable.BTN, 22f, d)
        setPadding((8 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        dropColor = c2
        val s = (40 * d).toInt()
        addView(IconView(ctx, icon, c1, c2, glyph, true), LayoutParams(s, s))
        addView(Th.text(ctx, caption, 13.5f, Th.BROWN, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
        }, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
    }
}

/** عنوان بتدرّج بني ثم برتقالي */
class WarmGradientText(ctx: Context) : TextView(ctx) {
    override fun onDraw(c: Canvas) {
        val w = max(1f, width.toFloat())
        paint.shader = LinearGradient(
            0f, 0f, w, 0f,
            intArrayOf(Th.BROWN, Th.BROWN, Color.parseColor("#E5470B"), Color.parseColor("#F26B1D")),
            floatArrayOf(0f, 0.55f, 0.82f, 1f), Shader.TileMode.CLAMP
        )
        super.onDraw(c)
    }
}
