package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var bitmap: Bitmap? = null
    private var loaded: Tracer.Loaded? = null
    private var threshold = 55
    private var detail = 40
    private var brushPx = 3
    private var colors = 36
    private var fillMode = false
    private var soft = 0
    private var blend = false
    private var pockets = true
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView
    private lateinit var clLabel: TextView

    private lateinit var previewOrig: ImageView
    private lateinit var previewSmall: ImageView
    private lateinit var pages: Array<View>
    private lateinit var navItems: Array<NavItem>

    private fun selectTab(i: Int) {
        for (k in pages.indices) pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in navItems.indices) navItems[k].setActive(k == i)
    }

    private fun showPreview(b: Bitmap) {
        preview.setImageBitmap(b)
        previewSmall.setImageBitmap(b)
    }

    private fun styleSeek(s: SeekBar) {
        val d = resources.displayMetrics.density
        val h = (8 * d).toInt()
        val bg = GradientDrawable().apply { cornerRadius = h / 2f; setColor(Color.parseColor("#EADBCB")); setSize(0, h) }
        val pr = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#F26B1D"), Color.parseColor("#FFA23A")))
            .apply { cornerRadius = h / 2f; setSize(0, h) }
        val clip = ClipDrawable(pr, Gravity.START, ClipDrawable.HORIZONTAL)
        val ld = LayerDrawable(arrayOf<Drawable>(bg, clip))
        ld.setId(0, android.R.id.background)
        ld.setId(1, android.R.id.progress)
        s.progressDrawable = ld
        s.thumb = orangeThumb(this)
        s.splitTrack = false
        s.setPadding((13 * d).toInt(), 0, (13 * d).toInt(), 0)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()
        window.statusBarColor = Th.CREAM
        window.navigationBarColor = Th.NAV2
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val screenH = resources.displayMetrics.heightPixels

        fun lpv(top: Int, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top.toFloat()) }

        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = WarmDrawable(WarmDrawable.CARD, 24f, d)
            setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
            elevation = 2f * d
        }

        fun previewCard(img: ImageView, height: Int): FrameLayout {
            img.apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.parseColor("#FFFDFB"))
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 18 * d) }
                }
                clipToOutline = true
            }
            return FrameLayout(this).apply {
                background = WarmDrawable(WarmDrawable.CARD, 24f, d)
                setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
                elevation = 2f * d
                addView(img, FrameLayout.LayoutParams(-1, height - dp(12f)))
            }
        }

        fun header(leftIcon: Int, title: String, rightIcon: Int, onLeft: () -> Unit, onRight: () -> Unit, underline: Boolean): FrameLayout {
            val fl = FrameLayout(this)
            val left = Th.squareBtn(this, leftIcon, Th.BROWN)
            val right = Th.squareBtn(this, rightIcon, Th.BROWN)
            left.setOnClickListener { onLeft() }
            right.setOnClickListener { onRight() }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(Th.text(this@MainActivity, title, 26f, Th.BROWN, true))
                if (underline) addView(View(this@MainActivity).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.parseColor("#F26B1D"), Color.parseColor("#FFA23A"))).apply { cornerRadius = 4f * d }
                }, LinearLayout.LayoutParams(dp(70f), dp(5f)).apply { topMargin = dp(4f) })
            }
            fl.addView(left, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.START or Gravity.CENTER_VERTICAL))
            fl.addView(right, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.END or Gravity.CENTER_VERTICAL))
            fl.addView(col, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            return fl
        }

        fun bigButton(icon: Int, label: String, orange: Boolean): LinearLayout = DropLinear(this).apply {
            dropColor = if (orange) Color.parseColor("#FF8A1F") else Color.parseColor("#E5470B")
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = WarmDrawable(if (orange) WarmDrawable.ORANGE else WarmDrawable.BTN, 26f, d)
            elevation = 3f * d
            addView(IconView(this@MainActivity, icon, 0, 0, if (orange) Color.WHITE else Color.parseColor("#B5461B")), LinearLayout.LayoutParams(dp(28f), dp(28f)))
            addView(Th.text(this@MainActivity, label, 18f, if (orange) Color.WHITE else Th.BROWN, true).apply { setPadding(dp(12f), 0, 0, 0) })
        }

        // ---------- عناصر مشتركة ----------
        preview = ImageView(this)
        previewSmall = ImageView(this)
        previewOrig = ImageView(this)
        status = Th.text(this, "لم تُختر صورة بعد", 12.5f, Th.MUTED).apply { gravity = Gravity.CENTER }

        thLabel = Th.text(this, "$threshold", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        dtLabel = Th.text(this, "$detail", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        clLabel = Th.text(this, "$colors", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        fgLabel = Th.text(this, "$brushPx", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val spLabel = Th.text(this, "x${Shared.speed.toInt()}", 15f, Th.BROWN, true).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        val seekCl = SeekBar(this).apply { max = 64; progress = colors }
        val seekFg = SeekBar(this).apply { max = 19; progress = brushPx - 1 }
        val seekSp = SeekBar(this).apply { max = 9; progress = Shared.speed.toInt() - 1 }
        for (s in listOf(seekTh, seekDt, seekCl, seekFg, seekSp)) styleSeek(s)

        fun sliderRow(label: String, seek: SeekBar, value: TextView, last: Boolean): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(Th.text(this@MainActivity, label, 14f, Th.BROWN, true), LinearLayout.LayoutParams(dp(112f), -2))
                addView(seek, LinearLayout.LayoutParams(0, dp(40f), 1f))
                addView(value, LinearLayout.LayoutParams(dp(44f), -2))
            }, LinearLayout.LayoutParams(-1, dp(46f)))
            if (!last) addView(View(this@MainActivity).apply { setBackgroundColor(Th.LINE) }, LinearLayout.LayoutParams(-1, dp(1f)))
        }

        val labMode = Th.text(this, "التلوين: فرشاة دقيقة", 14.5f, Th.BROWN, true)
        val labPock = Th.text(this, "البياض المحصور: خلفية", 14.5f, Th.BROWN, true)
        val labLay = Th.text(this, "الطبقات: طبقة لكل لون", 14.5f, Th.BROWN, true)
        val swMode = WarmSwitch(this).apply { checked = !fillMode }
        val swPock = WarmSwitch(this).apply { checked = pockets }
        val swLay = WarmSwitch(this).apply { checked = Shared.layers }

        fun optionRow(icon: Int, lab: TextView, sw: WarmSwitch): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = WarmDrawable(WarmDrawable.BTN, 18f, d)
            setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
            addView(IconView(this@MainActivity, icon, 0, 0, Th.BROWN), LinearLayout.LayoutParams(dp(30f), dp(30f)))
            addView(lab, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14f) })
            addView(sw)
        }

        fun cardTitle(icon: Int, title: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(FrameLayout(this@MainActivity).apply {
                background = WarmDrawable(WarmDrawable.SOFT, 28f, d)
                addView(IconView(this@MainActivity, icon, 0, 0, Th.BROWN), FrameLayout.LayoutParams(dp(24f), dp(24f), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(52f), dp(52f)))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(Th.text(this@MainActivity, title, 18f, Th.BROWN, true))
                addView(View(this@MainActivity).apply { setBackgroundColor(Th.LINE) }, LinearLayout.LayoutParams(-1, dp(1f)).apply { topMargin = dp(8f) })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14f) })
        }

        // ---------- الصفحة 1: الصورة ----------
        val btnPick = bigButton(Ic.IMAGE, "اختيار صورة", true)
        val btnAcc = bigButton(Ic.POWER, "تفعيل الخدمة", false)
        val gearTop = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 46f)
        val head1 = FrameLayout(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(Th.text(this@MainActivity, "MR NEGROO", 30f, Th.BROWN, true))
                addView(Th.text(this@MainActivity, "SKETCH STUDIO", 12f, Color.parseColor("#B5461B")).apply { letterSpacing = 0.3f })
            }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(gearTop, FrameLayout.LayoutParams(dp(46f), dp(46f), Gravity.END or Gravity.CENTER_VERTICAL))
        }
        val page1 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(head1, lpv(0))
            addView(previewCard(previewOrig, (screenH * 0.5f).toInt()), lpv(14))
            addView(btnPick, lpv(16, dp(64f)))
            addView(btnAcc, lpv(12, dp(56f)))
        }

        // ---------- الصفحة 2: الرسم ----------
        val brushBtn = Th.squareBtn(this, Ic.BRUSH, Th.BROWN, 64f, outlined = true)
        val dotBtn = FrameLayout(this).apply {
            background = WarmDrawable(WarmDrawable.BTN, 16f, d)
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#FF8A1F"), Color.parseColor("#E5300A"))).apply { shape = GradientDrawable.OVAL }
            }, FrameLayout.LayoutParams(dp(34f), dp(34f), Gravity.CENTER))
            Th.pressable(this)
        }
        val dotText = Th.text(this, "$colors", 11f, Color.WHITE, true)
        dotBtn.addView(dotText, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val undoBtn = Th.squareBtn(this, Ic.UNDO, Th.BROWN, 64f)
        val gearBtn = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 64f, orange = true)
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            for (v in listOf<View>(brushBtn, dotBtn, undoBtn, gearBtn))
                addView(v, LinearLayout.LayoutParams(0, dp(64f), 1f).apply { setMargins(dp(5f), 0, dp(5f), 0) })
        }
        val page2 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(header(Ic.BACK, "الرسم", Ic.POWER, { selectTab(0) }, { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, false), lpv(0))
            addView(previewCard(preview, (screenH * 0.5f).toInt()), lpv(14))
            addView(status, lpv(8))
            addView(tools, lpv(14))
        }

        // ---------- الصفحة 3: الإعدادات ----------
        val measCard = card().apply {
            addView(cardTitle(Ic.SLIDERS, "مقاييس الرسم"))
            addView(sliderRow("سواد الخطوط", seekTh, thLabel, false), lpv(10))
            addView(sliderRow("تفاصيل الخطوط", seekDt, dtLabel, false))
            addView(sliderRow("عدد الألوان", seekCl, clLabel, false))
            addView(sliderRow("سمك الفرشاة", seekFg, fgLabel, false))
            addView(sliderRow("سرعة الرسم", seekSp, spLabel, true))
        }
        val optCard = card().apply {
            addView(cardTitle(Ic.BRUSH, "خيارات الرسم"))
            addView(optionRow(Ic.PENCIL, labMode, swMode), lpv(12))
            addView(optionRow(Ic.CHECKER, labPock, swPock), lpv(8))
            addView(optionRow(Ic.LAYERS, labLay, swLay), lpv(8))
        }
        val gearTitle = Th.squareBtn(this, Ic.GEAR, Th.BROWN, 46f)
        val page3 = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(40f), dp(18f), dp(120f))
            addView(header(Ic.BACK, "الإعدادات", Ic.GEAR, { selectTab(1) }, {}, true), lpv(0))
            addView(previewCard(previewSmall, dp(230f)), lpv(12))
            addView(measCard, lpv(14))
            addView(optCard, lpv(14))
        }

        pages = arrayOf<View>(
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page1) },
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page2) },
            ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page3) }
        )
        navItems = arrayOf(NavItem(this, Ic.IMAGE, "الصورة"), NavItem(this, Ic.PENCIL, "الرسم"), NavItem(this, Ic.GEAR, "الإعدادات"))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = WarmDrawable(WarmDrawable.NAV, 34f, d, true)
            setPadding(dp(16f), dp(8f), dp(16f), dp(14f))
            for (ni in navItems) addView(ni, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) })
        }
        for (i in navItems.indices) navItems[i].setOnClickListener { selectTab(i) }

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Th.CREAM)
        for (p in pages) frame.addView(p, FrameLayout.LayoutParams(-1, -1))
        frame.addView(nav, FrameLayout.LayoutParams(-1, dp(96f), Gravity.BOTTOM))
        setContentView(frame)
        selectTab(0)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9)
        }

        if (b == null) {
            var sp: View? = null
            sp = SplashView(this) { sp?.let { v -> frame.post { frame.removeView(v) } } }
            frame.addView(sp, FrameLayout.LayoutParams(-1, -1))
        }

        // ---------- الأحداث ----------
        gearTop.setOnClickListener { selectTab(2) }
        gearBtn.setOnClickListener { selectTab(2) }
        btnAcc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "اختر صورة"), 1)
        }

        fun applyMode(precise: Boolean) {
            fillMode = !precise
            labMode.text = if (precise) "التلوين: فرشاة دقيقة" else "التلوين: تعبئة Fill"
            swMode.checked = precise
            process()
        }
        swMode.onChange = { v -> applyMode(v) }
        brushBtn.setOnClickListener { applyMode(fillMode) }
        swPock.onChange = { v ->
            pockets = v
            labPock.text = if (v) "البياض المحصور: خلفية" else "البياض المحصور: يُرسم أبيض"
            process()
        }
        swLay.onChange = { v ->
            Shared.layers = v
            labLay.text = if (v) "الطبقات: طبقة لكل لون" else "الطبقات: طبقة واحدة"
        }
        val presets = intArrayOf(8, 14, 24, 36, 48, 64)
        dotBtn.setOnClickListener {
            var nx = presets[0]
            for (pv in presets) if (pv > colors) { nx = pv; break }
            colors = nx
            seekCl.progress = nx
            clLabel.text = "$nx"
            dotText.text = "$nx"
            process()
        }
        undoBtn.setOnClickListener {
            threshold = 55; detail = 40; colors = 36; brushPx = 3
            Shared.speed = 4f
            seekTh.progress = threshold - 20
            seekDt.progress = detail
            seekCl.progress = colors
            seekFg.progress = brushPx - 1
            seekSp.progress = 3
            thLabel.text = "$threshold"; dtLabel.text = "$detail"; clLabel.text = "$colors"; fgLabel.text = "$brushPx"; spLabel.text = "x4"
            dotText.text = "$colors"
            Toast.makeText(this, "تمت إعادة الإعدادات الافتراضية", Toast.LENGTH_SHORT).show()
            process()
        }

        fun bind(seek: SeekBar, onChange: (Int) -> Unit) {
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { process() }
            })
        }
        bind(seekTh) { p -> threshold = 20 + p; thLabel.text = "$threshold" }
        bind(seekDt) { p -> detail = p; dtLabel.text = "$detail" }
        bind(seekCl) { p -> colors = p; clLabel.text = "$colors"; dotText.text = "$colors" }
        seekSp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Shared.speed = (1 + p).toFloat()
                spLabel.text = "x${1 + p}"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })
        bind(seekFg) { p -> getSharedPreferences("sb", MODE_PRIVATE).edit().remove("brushScreen").apply(); brushPx = 1 + p; fgLabel.text = "$brushPx" }
    }

    override fun onResume() {
        super.onResume()
        if (bitmap != null && Shared.phases.isEmpty()) process()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "جاري تحميل الصورة..."
            thread {
                val ld = Tracer.load(this, uri, 1500)
                runOnUiThread {
                    if (ld == null) {
                        status.text = "تعذّر فتح الصورة"
                    } else {
                        bitmap = ld.bmp
                        loaded = ld
                        previewOrig.setImageBitmap(ld.bmp)
                        selectTab(1)
                        process()
                    }
                }
            }
        }
    }

    // كم بكسل على الشاشة يساوي بكسل واحد من الصورة المحلَّلة (حسب منطقة الرسم المحفوظة)
    private fun screenScale(bmp: Bitmap): Float {
        val p = getSharedPreferences("sb", MODE_PRIVATE)
        var rw = resources.displayMetrics.widthPixels * 0.9f
        var rh = resources.displayMetrics.heightPixels * 0.7f
        if (p.contains("l")) {
            rw = p.getFloat("r", 0f) - p.getFloat("l", 0f)
            rh = p.getFloat("b", 0f) - p.getFloat("t", 0f)
        }
        val s = Math.min(rw / bmp.width, rh / bmp.height)
        return Math.max(0.05f, s)
    }

    private var gen = 0
    private val uiHandler = Handler(Looper.getMainLooper())
    private var fullJob: Runnable? = null

    // معاينة سريعة (دقة منخفضة) فوراً، ثم التحليل الكامل بعد توقف التعديل ~0.9 ث (وأي تحليل قديم يُلغى)
    private fun process() {
        val bmp = bitmap ?: return
        val ld = loaded ?: return
        val my = ++gen
        fullJob?.let { uiHandler.removeCallbacks(it) }
        status.text = "معاينة سريعة..."
        val t = threshold
        val dt = detail
        val sc = screenScale(bmp)
        val measured = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
        val eff = if (measured > 0f) measured else brushPx.toFloat()
        val fg = Math.max(1, Math.round(eff * 0.6f / sc))
        val cl = colors
        val fm = fillMode
        val sf = soft
        val bl = blend
        val pk = pockets
        val sn = Shared.speed <= 2f
        // 1) معاينة سريعة على نسخة مصغّرة
        val k = 0.3f
        thread {
            try {
                val sw = Math.max(64, (bmp.width * k).toInt())
                val sh = Math.max(64, (bmp.height * k).toInt())
                val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
                val r = Tracer.process(small, t, dt, Math.max(1, Math.round(fg * k)), Math.min(cl, 24), false, sf, bl, sn, pk)
                runOnUiThread { if (my == gen) { showPreview(r.preview); status.text = "المعاينة سريعة؛ جاري التحليل الكامل..." } }
            } catch (_: Throwable) {}
        }
        // 2) التحليل الكامل بعد توقف المستخدم عن التعديل
        val job = Runnable {
            thread {
                try {
                    if (my != gen) return@thread
                    val r = Tracer.process(bmp, t, dt, fg, cl, fm, sf, bl, sn, pk)
                    runOnUiThread {
                        if (my != gen) return@runOnUiThread
                        Shared.phases = r.phases
                        Shared.imgW = r.w
                        Shared.imgH = r.h
                        Shared.fx0 = ld.fx0
                        Shared.fy0 = ld.fy0
                        Shared.fw = ld.fw
                        Shared.fh = ld.fh
                        Shared.aspect = ld.aspect
                        showPreview(r.preview)
                        var total = 0
                        for (p in r.phases) total += p.strokes.size
                        val want = r.lineThick * sc
                        val mb = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
                        val rec = if (want > 0f) {
                            " | سمك الخطوط الأصلي ≈ ${"%.1f".format(want)} بكسل" +
                                (if (mb > 0f) " | فرشاتك المقاسة = ${mb.toInt()} بكسل" +
                                    (if (mb > want * 1.4f) ": كبيرة، صغّر Size إلى ${"%.0f".format(100f * want / mb)}% تقريباً" else ": مناسبة")
                                else " | قِس فرشاتك بزر 📏")
                        } else ""
                        status.text = "جاهز: ${r.phases.size} مرحلة، $total خط$rec"
                    }
                } catch (e: Throwable) {
                    runOnUiThread { if (my == gen) status.text = "خطأ في التحليل: ${e.message}" }
                }
            }
        }
        fullJob = job
        uiHandler.postDelayed(job, 900)
    }
}
